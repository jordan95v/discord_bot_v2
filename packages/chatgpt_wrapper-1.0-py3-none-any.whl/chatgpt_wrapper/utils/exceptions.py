class ChatGPTError(Exception):
    """Happens when there is an error with ChatGPT."""
